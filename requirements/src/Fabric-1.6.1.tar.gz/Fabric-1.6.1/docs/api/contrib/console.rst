Console Output Utilities
========================

.. automodule:: fabric.contrib.console
    :members:
